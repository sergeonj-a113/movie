import React, { useCallback, useEffect, useState } from 'react';
import { Film, Plus, Search, SlidersHorizontal, Clapperboard, Clock3, Star, Trash2, Pencil, Sparkles, RefreshCw, X, Check, ChevronLeft, ChevronRight, PlayCircle } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
const genres = ['Action','Comedy','Drama','Horror','Sci-Fi','Romance','Thriller'];
const platforms = ['Netflix','Prime Video','Hotstar','Theatre','Other'];
const statuses = ['To Watch','Watching','Watched'];
const blank = { title:'', genre:'Drama', releaseYear:new Date().getFullYear(), runtime:120, platform:'Netflix', priority:3 };
async function request(path, options={}) {
  const res = await fetch(`${API}${path}`, { headers:{'Content-Type':'application/json'}, ...options });
  const body = await res.json().catch(()=>({message:'Unexpected server response'}));
  if (!res.ok) throw new Error(body.message || 'Request failed');
  return body;
}
function App() {
  const [movies,setMovies] = useState([]), [stats,setStats] = useState(null), [page,setPage] = useState(1), [pages,setPages] = useState(1);
  const [status,setStatus] = useState(''), [genre,setGenre] = useState(''), [search,setSearch] = useState('');
  const [modal,setModal] = useState(false), [editing,setEditing] = useState(null), [form,setForm] = useState(blank), [error,setError] = useState(''), [busy,setBusy] = useState(false);
  const [ratingMovie,setRatingMovie] = useState(null), [rating,setRating] = useState(8), [notice,setNotice] = useState('');
  const refresh = useCallback(async () => {
    try {
      const params = new URLSearchParams({page,limit:6});
      if(status) params.set('status',status); if(genre) params.set('genre',genre); if(search.trim()) params.set('search',search.trim());
      const [m,s] = await Promise.all([request(`/movies?${params}`),request('/stats')]);
      setMovies(m.data.movies); setPages(Math.max(1,m.data.totalPages)); setStats(s.data);
    } catch(e) { setError(`${e.message}. Check the backend and MongoDB Atlas connection.`); }
  },[page,status,genre,search]);
  useEffect(()=>{refresh()},[refresh]);
  const openAdd = () => { setEditing(null); setForm(blank); setError(''); setModal(true); };
  const openEdit = movie => { setEditing(movie); setForm({title:movie.title,genre:movie.genre,releaseYear:movie.releaseYear,runtime:movie.runtime,platform:movie.platform,priority:movie.priority}); setError(''); setModal(true); };
  const save = async e => {
    e.preventDefault(); setError('');
    const year=Number(form.releaseYear), runtime=Number(form.runtime), priority=Number(form.priority);
    if(year<1950 || year>new Date().getFullYear()) return setError(`Release year must be between 1950 and ${new Date().getFullYear()}.`);
    if(runtime<30 || runtime>300) return setError('Runtime must be between 30 and 300 minutes.');
    if(priority<1 || priority>5) return setError('Priority must be between 1 and 5.');
    setBusy(true);
    try {
      const payload={...form,runtime,priority};
      if(editing) await request(`/movies/${editing._id}`,{method:'PUT',body:JSON.stringify(payload)});
      else await request('/movies',{method:'POST',body:JSON.stringify(payload)});
      setModal(false); setNotice(editing?'Movie updated successfully':'Movie added successfully'); await refresh();
    } catch(e) { setError(e.message); } finally { setBusy(false); }
  };
  const transition = async (movie,next) => {
    if(next==='Watched') { setRatingMovie(movie); setRating(8); return; }
    try { await request(`/movies/${movie._id}/status`,{method:'PATCH',body:JSON.stringify({status:next})}); setNotice('Status updated'); await refresh(); }
    catch(e){setNotice(e.message);}
  };
  const markWatched = async e => {
    e.preventDefault();
    try { await request(`/movies/${ratingMovie._id}/status`,{method:'PATCH',body:JSON.stringify({status:'Watched',rating:Number(rating)})}); setRatingMovie(null); setNotice('Marked as watched'); await refresh(); }
    catch(e){setNotice(e.message);}
  };
  const changeRating = async movie => {
    const val=window.prompt('Enter a rating from 1 to 10',movie.rating);
    if(val===null) return;
    try { await request(`/movies/${movie._id}/rating`,{method:'PATCH',body:JSON.stringify({rating:Number(val)})}); setNotice('Rating updated'); await refresh(); }
    catch(e){setNotice(e.message);}
  };
  const remove = async movie => {
    if(!window.confirm(`Delete "${movie.title}"? This cannot be undone.`)) return;
    try { await request(`/movies/${movie._id}`,{method:'DELETE'}); setNotice('Movie deleted'); await refresh(); }
    catch(e){setNotice(e.message);}
  };
  const watchNext = async () => {
    try { const r=await request('/movies/watch-next'); setNotice(`Watch next: ${r.data.title} (${r.data.code}) · Priority ${r.data.priority} · ${r.data.runtime} min`); }
    catch(e){setNotice(e.message);}
  };
  const field = (key,value) => setForm(f=>({...f,[key]:value}));
  return <div className="app-shell">
    <header className="topbar"><a className="brand" href="#"><span className="brand-icon"><Film size={21}/></span><span>Reel<span className="accent">List</span><small>YOUR PERSONAL CINEMA</small></span></a><div className="top-actions"><span className="live-dot"/> <span className="live-label">WATCHLIST STUDIO</span><button className="btn primary small" onClick={openAdd}><Plus size={16}/> Add movie</button></div></header>
    <main>
      <section className="hero"><div className="hero-copy"><div className="eyebrow"><Sparkles size={14}/> YOUR NEXT GREAT STORY STARTS HERE</div><h1>Your movies.<br/><em>Your next obsession.</em></h1><p>A thoughtfully curated space for everything you want to watch, are watching, and will never stop talking about.</p><div className="hero-buttons"><button className="btn primary" onClick={watchNext}><PlayCircle size={17}/> What should I watch next?</button><button className="btn ghost" onClick={openAdd}><Plus size={17}/> Add to watchlist</button></div></div><div className="hero-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="poster poster-back"><div className="poster-moon"/><span>AFTER<br/>HOURS</span></div><div className="poster poster-front"><div className="poster-sun"/><span>THE<br/>LAST<br/>FRAME</span><small>A STORY IN LIGHT</small></div><div className="floating-tag"><Clapperboard size={16}/><span><b>Now showing</b><small>Your next favorite</small></span></div></div></section>
      <section className="stats-grid">
        <Stat icon={<Clapperboard/>} label="TOTAL MOVIES" value={stats?Object.values(stats.statusCounts).reduce((a,b)=>a+b,0):'—'} note="In your collection"/>
        <Stat icon={<Clock3/>} label="HOURS WATCHED" value={stats?.totalHoursWatched ?? '—'} note="Time well spent"/>
        <Stat icon={<Star/>} label="AVERAGE RATING" value={stats?.averageRating ?? '—'} note={`${stats?.watchedCount ?? 0} movies rated`}/>
        <Stat icon={<Sparkles/>} label="TOP GENRE" value={stats?.topWatchedGenre?.genre || '—'} note={stats?.topWatchedGenre?`${stats.topWatchedGenre.count} watched movies`:'Start watching to unlock'}/>
      </section>
      <section className="collection-head"><div><div className="eyebrow">THE COLLECTION</div><h2>Your watchlist<span className="count-pill">{stats?Object.values(stats.statusCounts).reduce((a,b)=>a+b,0):0}</span></h2><p>Keep your next movie night one step ahead.</p></div><button className="btn outline" onClick={refresh}><RefreshCw size={15}/> Refresh</button></section>
      <section className="toolbar"><div className="search-box"><Search size={17}/><input value={search} placeholder="Search your movies..." onChange={e=>{setSearch(e.target.value);setPage(1)}}/></div><div className="filter-label"><SlidersHorizontal size={15}/> FILTER BY</div><select value={status} onChange={e=>{setStatus(e.target.value);setPage(1)}}><option value="">All statuses</option>{statuses.map(s=><option key={s}>{s}</option>)}</select><select value={genre} onChange={e=>{setGenre(e.target.value);setPage(1)}}><option value="">All genres</option>{genres.map(g=><option key={g}>{g}</option>)}</select><button className="clear-filters" onClick={()=>{setStatus('');setGenre('');setSearch('');setPage(1)}}>Clear</button></section>
      {error && !modal && <div className="alert error">{error}<button onClick={()=>setError('')}><X size={15}/></button></div>}
      {notice && <div className="alert notice">{notice}<button onClick={()=>setNotice('')}><X size={15}/></button></div>}
      <section className="movie-grid">{movies.map(movie=><article className="movie-card" key={movie._id}><div className={`movie-art art-${genres.indexOf(movie.genre)%7}`}><div className="art-grain"/><span className="art-genre">{movie.genre}</span><span className="art-initial">{movie.title.slice(0,1).toUpperCase()}</span><span className="movie-code">{movie.code}</span><span className={`status-badge ${movie.status.toLowerCase().replace(' ','-')}`}>{movie.status}</span></div><div className="movie-content"><div className="movie-title-row"><h3>{movie.title}</h3><span className="priority">P{movie.priority}</span></div><div className="movie-meta"><span>{movie.releaseYear}</span><i/> <span><Clock3 size={13}/>{movie.runtime} min</span><i/> <span>{movie.platform}</span></div><div className="movie-bottom"><span className="rating">{movie.rating ? <><Star size={14} fill="currentColor"/>{movie.rating}/10</> : <span className="no-rating">Not rated</span>}</span><div className="card-actions"><button title="Edit movie" onClick={()=>openEdit(movie)}><Pencil size={15}/></button>{movie.status==='Watched' && <button title="Edit rating" onClick={()=>changeRating(movie)}><Star size={15}/></button>}<button title={movie.status==='Watching'?'Watching movies cannot be deleted':'Delete movie'} disabled={movie.status==='Watching'} onClick={()=>remove(movie)}><Trash2 size={15}/></button></div></div>
      {movie.status!=='Watched' && <div className="status-control"><label>Move to</label><select value="" onChange={e=>{if(e.target.value)transition(movie,e.target.value)}}><option value="">Choose status…</option>{(movie.status==='To Watch'?['Watching','Watched']:['Watched','To Watch']).map(s=><option key={s}>{s}</option>)}</select></div>}
      {movie.status==='Watched' && <div className="watched-note"><Check size={13}/> Watched {movie.watchedDate?new Date(movie.watchedDate).toLocaleDateString():''}</div>}
      </div></article>)}
      {!movies.length && <div className="empty-state"><div className="empty-icon"><Film size={28}/></div><h3>Your next movie is waiting</h3><p>No movies match these filters. Add one or clear your filters to get started.</p><button className="btn primary" onClick={openAdd}><Plus size={16}/> Add your first movie</button></div>}
      </section>
      <div className="pagination"><span>Showing <b>{movies.length}</b> of your collection · Page {page} of {pages}</span><div><button disabled={page<=1} onClick={()=>setPage(p=>p-1)}><ChevronLeft size={17}/></button><span>{page}</span><button disabled={page>=pages} onClick={()=>setPage(p=>p+1)}><ChevronRight size={17}/></button></div></div>
      <footer><span><Film size={15}/> ReelList</span><span>MADE FOR MOVIE PEOPLE <span className="footer-star">✳</span></span></footer>
    </main>
    {modal && <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setModal(false)}}><section className="modal"><div className="modal-head"><div><div className="eyebrow">{editing?'UPDATE YOUR COLLECTION':'ADD SOMETHING GOOD'}</div><h2>{editing?'Edit movie':'Add a movie'}</h2></div><button className="icon-btn" onClick={()=>setModal(false)}><X/></button></div>{error&&<div className="alert error">{error}</div>}<form onSubmit={save}><label className="full">Movie title<input required maxLength="120" value={form.title} onChange={e=>field('title',e.target.value)} placeholder="e.g. Eternal Sunshine of the Spotless Mind"/></label><label>Genre<select value={form.genre} onChange={e=>field('genre',e.target.value)}>{genres.map(g=><option key={g}>{g}</option>)}</select></label><label>Release year<input type="number" required min="1950" max={new Date().getFullYear()} disabled={!!editing} value={form.releaseYear} onChange={e=>field('releaseYear',e.target.value)}/></label><label>Runtime (minutes)<input type="number" required min="30" max="300" value={form.runtime} onChange={e=>field('runtime',e.target.value)}/></label><label>Platform<select value={form.platform} onChange={e=>field('platform',e.target.value)}>{platforms.map(p=><option key={p}>{p}</option>)}</select></label><label className="full">Priority <span className="sub-label">5 is the highest</span><div className="priority-picker">{[1,2,3,4,5].map(n=><button type="button" key={n} className={Number(form.priority)===n?'selected':''} onClick={()=>field('priority',n)}>{n}<Star size={13} fill={Number(form.priority)>=n?'currentColor':'none'}/></button>)}</div></label><div className="modal-actions"><button type="button" className="btn ghost" onClick={()=>setModal(false)}>Cancel</button><button disabled={busy} className="btn primary" type="submit">{busy?'Saving…':editing?'Save changes':'Add movie'} <Plus size={16}/></button></div></form></section></div>}
    {ratingMovie && <div className="modal-backdrop"><section className="modal rating-modal"><div className="modal-head"><div><div className="eyebrow">ONE LAST THING</div><h2>How was the movie?</h2><p>Rate <b>{ratingMovie.title}</b> before marking it watched.</p></div><button className="icon-btn" onClick={()=>setRatingMovie(null)}><X/></button></div><form onSubmit={markWatched}><label>Rating (1–10)<input type="number" min="1" max="10" required value={rating} onChange={e=>setRating(e.target.value)}/></label><div className="modal-actions"><button type="button" className="btn ghost" onClick={()=>setRatingMovie(null)}>Cancel</button><button className="btn primary" type="submit">Mark as watched <Check size={16}/></button></div></form></section></div>}
  </div>;
}
function Stat({icon,label,value,note}) { return <div className="stat-card"><div className="stat-top"><span className="stat-icon">{icon}</span><span className="stat-label">{label}</span></div><div className="stat-value">{value}</div><div className="stat-note">{note}</div></div> }
export default App;
