import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import movieRoutes from './src/routes/movies.js';
import { stats } from './src/controllers/movies.js';

dotenv.config();
const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json());
app.get('/api/health', (_req, res) => res.json({ success: true, message: 'API is running', data: { status: 'ok' } }));
app.use('/api/movies', movieRoutes);
app.get('/api/stats', stats);
app.use((req, res) => res.status(404).json({ success: false, message: `Route not found: ${req.method} ${req.originalUrl}`, data: null }));
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.status || 500).json({ success: false, message: err.message || 'Server error', data: null });
});
const port = process.env.PORT || 5000;
mongoose.connect(process.env.MONGODB_URI)
  .then(() => { console.log('MongoDB connected'); app.listen(port, () => console.log(`API listening on ${port}`)); })
  .catch(err => { console.error('MongoDB connection failed:', err.message); process.exit(1); });
