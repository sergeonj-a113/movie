import Movie from '../models/Movie.js';
import YearCounter from '../models/YearCounter.js';
import { send, fail } from '../utils/response.js';

const genres = ['Action','Comedy','Drama','Horror','Sci-Fi','Romance','Thriller'];
const platforms = ['Netflix','Prime Video','Hotstar','Theatre','Other'];
const currentYear = () => new Date().getFullYear();
const validate = (body, partial = false) => {
  const required = ['title','genre','releaseYear','runtime','platform','priority'];
  if (!partial) for (const key of required) if (body[key] === undefined || body[key] === '') throw fail(400, `${key} is required`);
  if (body.title !== undefined && !String(body.title).trim()) throw fail(400, 'Title is required');
  if (body.genre !== undefined && !genres.includes(body.genre)) throw fail(400, 'Invalid genre');
  if (body.platform !== undefined && !platforms.includes(body.platform)) throw fail(400, 'Invalid platform');
  if (body.releaseYear !== undefined && (!Number.isInteger(Number(body.releaseYear)) || Number(body.releaseYear) < 1950 || Number(body.releaseYear) > currentYear())) throw fail(400, `Release year must be between 1950 and ${currentYear()}`);
  if (body.runtime !== undefined && (!Number.isInteger(Number(body.runtime)) || Number(body.runtime) < 30 || Number(body.runtime) > 300)) throw fail(400, 'Runtime must be between 30 and 300 minutes');
  if (body.priority !== undefined && (!Number.isInteger(Number(body.priority)) || Number(body.priority) < 1 || Number(body.priority) > 5)) throw fail(400, 'Priority must be an integer from 1 to 5');
};
const asyncHandler = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);

export const list = asyncHandler(async (req,res) => {
  const page = Math.max(1, parseInt(req.query.page) || 1), limit = 6;
  const filter = {};
  if (req.query.status && ['To Watch','Watching','Watched'].includes(req.query.status)) filter.status = req.query.status;
  if (req.query.genre && genres.includes(req.query.genre)) filter.genre = req.query.genre;
  if (req.query.search) filter.title = { $regex: String(req.query.search).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i' };
  const total = await Movie.countDocuments(filter);
  const movies = await Movie.find(filter).sort({ status: 1, priority: -1, runtime: 1, createdAt: -1 }).skip((page-1)*limit).limit(limit);
  send(res,200,'Movies retrieved',{ movies, page, limit, total, totalPages: Math.ceil(total/limit) });
});
export const create = asyncHandler(async (req,res) => {
  validate(req.body);
  const title = String(req.body.title).trim();
  const dupe = await Movie.findOne({ title: { $regex: `^${title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, $options:'i' }, releaseYear: Number(req.body.releaseYear) });
  if (dupe) return send(res,409,'A movie with this title and release year already exists',null);
  const year = Number(req.body.releaseYear);
  const counter = await YearCounter.findOneAndUpdate({ _id: year }, { $inc: { seq: 1 } }, { upsert: true, new: true, setDefaultsOnInsert: true });
  const code = `MV-${year}-${String(counter.seq).padStart(3,'0')}`;
  const movie = await Movie.create({ title, genre:req.body.genre, releaseYear:year, runtime:Number(req.body.runtime), platform:req.body.platform, priority:Number(req.body.priority), code, status:'To Watch' });
  send(res,201,'Movie created',movie);
});
export const getOne = asyncHandler(async (req,res) => {
  const movie = await Movie.findById(req.params.id);
  if (!movie) throw fail(404,'Movie not found');
  send(res,200,'Movie retrieved',movie);
});
export const update = asyncHandler(async (req,res) => {
  const movie = await Movie.findById(req.params.id);
  if (!movie) throw fail(404,'Movie not found');
  if (movie.status === 'Watched') {
    // Watched remains final; descriptive fields may still be edited.
  }
  const allowed = ['title','genre','runtime','platform','priority'];
  const patch = {};
  for (const k of allowed) if (req.body[k] !== undefined) patch[k] = req.body[k];
  validate(patch,true);
  if (patch.title !== undefined) {
    patch.title = String(patch.title).trim();
    const duplicate = await Movie.findOne({ _id: { $ne: movie._id }, title: { $regex:`^${patch.title.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}$`, $options:'i' }, releaseYear: movie.releaseYear });
    if (duplicate) return send(res,409,'A movie with this title and release year already exists',null);
  }
  if (patch.runtime !== undefined) patch.runtime = Number(patch.runtime);
  if (patch.priority !== undefined) patch.priority = Number(patch.priority);
  Object.assign(movie,patch);
  await movie.save();
  send(res,200,'Movie updated',movie);
});
export const changeStatus = asyncHandler(async (req,res) => {
  const movie = await Movie.findById(req.params.id);
  if (!movie) throw fail(404,'Movie not found');
  const next = req.body.status;
  const allowed = { 'To Watch':['Watching','Watched'], 'Watching':['Watched','To Watch'], 'Watched':[] };
  if (!allowed[movie.status]?.includes(next)) throw fail(400,`Invalid status transition: ${movie.status} → ${next}`);
  if (next === 'Watched') {
    const rating = Number(req.body.rating);
    if (!Number.isInteger(rating) || rating < 1 || rating > 10) throw fail(400,'A rating from 1 to 10 is required when marking a movie Watched');
    movie.rating = rating; movie.watchedDate = new Date();
  } else {
    if (req.body.rating !== undefined && req.body.rating !== null && req.body.rating !== '') throw fail(400,'Rating is only allowed for Watched movies');
    movie.rating = null; movie.watchedDate = null;
  }
  movie.status = next;
  await movie.save();
  send(res,200,'Movie status updated',movie);
});
export const updateRating = asyncHandler(async (req,res) => {
  const movie = await Movie.findById(req.params.id);
  if (!movie) throw fail(404,'Movie not found');
  if (movie.status !== 'Watched') throw fail(400,'Rating can only be set for Watched movies');
  const rating = Number(req.body.rating);
  if (!Number.isInteger(rating) || rating < 1 || rating > 10) throw fail(400,'Rating must be an integer from 1 to 10');
  movie.rating = rating; await movie.save();
  send(res,200,'Rating updated',movie);
});
export const remove = asyncHandler(async (req,res) => {
  const movie = await Movie.findById(req.params.id);
  if (!movie) throw fail(404,'Movie not found');
  if (movie.status === 'Watching') throw fail(400,'Movies in Watching status cannot be deleted');
  await movie.deleteOne();
  send(res,200,'Movie deleted',movie);
});
export const watchNext = asyncHandler(async (_req,res) => {
  const movie = await Movie.findOne({ status:'To Watch' }).sort({ priority:-1, runtime:1, createdAt:1 });
  if (!movie) return send(res,404,'No movies are currently in To Watch status',null);
  send(res,200,'Your next movie recommendation',movie);
});
export const stats = asyncHandler(async (_req,res) => {
  const statusRows = await Movie.aggregate([{ $group:{ _id:'$status', count:{ $sum:1 } } }]);
  const statusCounts = { 'To Watch':0, 'Watching':0, 'Watched':0 };
  statusRows.forEach(x => statusCounts[x._id] = x.count);
  const watched = await Movie.aggregate([
    { $match:{ status:'Watched' } },
    { $group:{ _id:null, runtime:{ $sum:'$runtime' }, averageRating:{ $avg:'$rating' }, count:{ $sum:1 } } }
  ]);
  const genre = await Movie.aggregate([
    { $match:{ status:'Watched' } }, { $group:{ _id:'$genre', count:{ $sum:1 } } },
    { $sort:{ count:-1, _id:1 } }, { $limit:1 }
  ]);
  const w = watched[0] || { runtime:0, averageRating:null, count:0 };
  send(res,200,'Statistics retrieved',{
    statusCounts, totalHoursWatched:Math.round((w.runtime/60)*10)/10,
    averageRating:w.averageRating == null ? null : Math.round(w.averageRating*10)/10,
    topWatchedGenre:genre[0] ? { genre:genre[0]._id, count:genre[0].count } : null,
    watchedCount:w.count
  });
});
