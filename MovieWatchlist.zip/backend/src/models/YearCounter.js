import mongoose from 'mongoose';
export default mongoose.model('YearCounter', new mongoose.Schema({
  _id: { type: Number },
  seq: { type: Number, default: 0 }
}, { versionKey: false }));
