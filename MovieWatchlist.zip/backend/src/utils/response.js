export const send = (res, status, message, data = null) => res.status(status).json({ success: status < 400, message, data });
export const fail = (status, message) => Object.assign(new Error(message), { status });
